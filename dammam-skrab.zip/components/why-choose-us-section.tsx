import { Card, CardContent } from "@/components/ui/card"
import { Icons } from "./icons"
import Image from "next/image"
import { internalLinks } from "@/lib/links"
import Link from "next/link"

const whyChooseUsData = [
  {
    icon: Icons.award, // Trust & Expertise
    title: "خبرة متخصصة في شراء الأثاث المستعمل بالدمام",
    description:
      "أكثر من 10 سنوات من الخبرة المتخصصة في شراء الأثاث المستعمل بالدمام والمنطقة الشرقية. فريقنا من الخبراء المعتمدين يقدم تقييماً دقيقاً وعادلاً لجميع قطع الأثاث، من غرف النوم والصالات إلى المكاتب ومعدات المطاعم المستعملة.",
    image: "/images/used-furniture-dammam.jpg",
  },
  {
    icon: Icons.dollarSign, // Best Prices
    title: "أعلى الأسعار لشراء المكيفات المستعملة والسكراب",
    description:
      "نضمن لك أفضل الأسعار في السوق لشراء المكيفات المستعملة ومكيفات السكراب في الدمام، الخبر، القطيف، والجبيل. نقوم بدراسة السوق يومياً لضمان حصولك على أعلى عائد من بيع مكيفاتك القديمة أو المعطلة.",
    image: "/images/used-and-scrap-airconditioner.webp",
  },
  {
    icon: Icons.zap, // Fast Service
    title: "خدمة فورية وتقييم مجاني في نفس اليوم",
    description:
      "نصل إليك خلال ساعات قليلة في جميع أنحاء المنطقة الشرقية بما في ذلك الأحساء والهفوف. نقدم تقييماً مجانياً فورياً لأثاثك ومكيفاتك مع إمكانية الشراء والدفع نقداً في نفس الجلسة، مما يوفر عليك الوقت والجهد.",
    image: "/images/fast-service-eastern-province.jpg",
  },
  {
    icon: Icons.shield, // Licensed & Insured
    title: "شركة مرخصة ومؤمنة بالكامل",
    description:
      "نعمل بتراخيص رسمية من الجهات المختصة في المملكة العربية السعودية، ونحمل تأميناً شاملاً يغطي جميع عمليات الشراء والنقل. هذا يضمن لك التعامل الآمن والقانوني عند بيع ممتلكاتك المستعملة.",
    image: "/images/licensed-company-ksa.jpg",
  },
  {
    icon: Icons.recycle, // Eco-friendly
    title: "معالجة بيئية مستدامة للمواد المعاد تدويرها",
    description:
      "نتبع أحدث المعايير البيئية في إعادة تدوير المعادن والمكيفات والأثاث المستعمل. نساهم في الاقتصاد الدائري من خلال إعطاء حياة جديدة للمواد المستعملة، مما يقلل من التلوث البيئي ويدعم التنمية المستدامة في المنطقة الشرقية.",
    image: "/images/sustainable-recycling.jpg",
  },
  {
    icon: Icons.truck, // Free Transportation
    title: "نقل مجاني وفريق متخصص للتفكيك والتحميل",
    description:
      "نوفر خدمة النقل المجاني لجميع المشتريات بغض النظر عن الحجم أو الوزن في جميع مناطق الدمام والخبر والقطيف. فريقنا المدرب يتولى تفكيك الأثاث الثقيل ونقل المكيفات بأمان تام دون أي تكلفة إضافية عليك، مع ضمان عدم تضرر منزلك أو مكتبك.",
    image: "/images/free-transport-disassembly.jpg",
  }
]



export function WhyChooseUsSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4">
            لماذا نحن الأفضل في{' '}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-primary">
              <strong>شراء مكيفات مستعمل بالدمام</strong>
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedFurniture} className="gradient-text hover:border-b-2 border-primary">
              الأثاث المستعمل
            </Link>
          </h2>

          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            نحن{' '}
            <Link href={internalLinks.usedFurnitureDammam} className="gradient-text hover:border-b-2 border-primary">
              أفضل شركة شراء أثاث مستعمل بالدمام
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.scrapQatif} className="gradient-text hover:border-b-2 border-primary">
              المشترون الرائدون للسكراب في القطيف
            </Link>،{' '}
            الخبر، الجبيل، الأحساء، وفي جميع أنحاء المنطقة الشرقية.
            نقدم خدمات شراء{' '}
            <Link href={internalLinks.usedFurniture} className="gradient-text hover:border-b-2 border-primary">
              الأثاث المستعمل
            </Link>،{' '}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-primary">
              المكيفات المستعملة والسكراب
            </Link>،{' '}
            جميع أنواع المعادن والخردة، بالإضافة إلى{' '}
            <Link href={internalLinks.restaurantEquipment} className="gradient-text hover:border-b-2 border-primary">
              معدات المطاعم المستعملة
            </Link>،{' '}
            <Link href={internalLinks.usedKitchens} className="gradient-text hover:border-b-2 border-primary">
              المطابخ الألمنيوم المستعملة
            </Link>،{' '}
            <Link href={internalLinks.officeFurniture} className="gradient-text hover:border-b-2 border-primary">
              الأثاث المكتبي
            </Link>{' '}
            والأجهزة الكهربائية المستعملة.
            سواء كنت في الدمام، الخبر، القطيف أو أي مكان في المنطقة الشرقية، فنحن نضمن لك أعلى الأسعار وخدمة سريعة وموثوقة.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {whyChooseUsData.map((item, index) => (
            <Card
              key={index}
              className="group hover:shadow-xl transition-all duration-300 animate-slide-up overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="grid md:grid-cols-2 h-full">
                <div className="relative overflow-hidden">
                  <Image
                    src={item.image || "/placeholder.jpg"}
                    alt={item.title}
                    width={300}
                    height={200}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6 flex flex-col justify-center">
                  <div className="flex items-start space-x-2">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:bg-blue-600/20 transition-colors">
                      <item.icon className="w-6 h-6 text-blue-600 hover:border-b-2 border-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-3 group-hover:gradient-text hover:border-b-2 border-primary transition-colors">{item.title}</h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
