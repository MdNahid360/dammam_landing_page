import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Icons } from "./icons"
import Link from "next/link"
import { Blog } from "@/types"
import { API_ENDPOINTS } from "@/lib/utils"
import BlogCard from "./blog-card"
import { internalLinks } from "@/lib/links"


export async function getBlogs(): Promise<Blog[]> {
  try {
    const res = await fetch(`${API_ENDPOINTS.blogs}?domain=${API_ENDPOINTS.domain}&limit=6&offset=0`, {
      next: { revalidate: 60 * 30 }, // Cache for 30 mins
    })
    if (!res.ok) throw new Error("Failed to fetch")
    const json = await res.json()
    return json?.blogs ?? []
  } catch {
    return []
  }
}

export async function BlogsSection() {
  const blogs = await getBlogs()

  // if not found show a notfound ui
  if (blogs.length === 0) return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
            لا توجد مقالات متاحة حالياً
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            سنقوم بنشر مقالات جديدة قريباً
          </p>
        </div>
      </div>
    </section>
  )

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 pb-2.5">
            نصائح ومقالات حول شراء{' '}
            <Link href={internalLinks.usedFurniture} className="hover:border-b-2 border-primary gradient-text">
              الأثاث المستعمل
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedAirConditioners} className="hover:border-b-2 border-primary gradient-text">
              <strong>بالدمام المكيفات المستعملة</strong>
            </Link>{' '}

          </h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            تابع أحدث المقالات والنصائح المفيدة حول{' '}
            <Link href={internalLinks.usedFurnitureDammam} className="gradient-text hover:border-b-2 border-primary">
              شراء الأثاث المستعمل بالدمام
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-primary">
              المكيفات المستعملة
            </Link>،{' '}
            <Link href={internalLinks.scrapACs} className="gradient-text hover:border-b-2 border-primary">
              مكيفات السكراب
            </Link>،{' '}
            <Link href={internalLinks.scrapMetals} className="gradient-text hover:border-b-2 border-primary">
              خردة المعادن
            </Link>{' '}
            في الخبر، القطيف، الجبيل والمنطقة الشرقية.
            نقدم أيضاً دليلاً شاملاً لـ{' '}
            <Link href={internalLinks.restaurantEquipment} className="gradient-text hover:border-b-2 border-primary">
              شراء معدات المطاعم المستعملة
            </Link>،{' '}
            <Link href={internalLinks.officeFurniture} className="gradient-text hover:border-b-2 border-primary">
              الأثاث المكتبي المستعمل
            </Link>،{' '}
            <Link href={internalLinks.usedKitchens} className="gradient-text hover:border-b-2 border-primary">
              المطابخ المستعملة
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedHomeAppliances} className="gradient-text hover:border-b-2 border-primary">
              الأجهزة الكهربائية المستعملة
            </Link>{' '}
            بأعلى الأسعار وأفضل الخدمات في المملكة العربية السعودية.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs.map((blog: Blog) => (
            <BlogCard key={blog._id} blog={blog} />
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/blogs"
            className="inline-flex items-center text-blue-600 hover:text-blue-600/80"
            rel="noopener noreferrer"
          >
            جميع المقالات
            <Icons.arrowRight className="w-4 h-4 mr-2" />
          </Link>
        </div>
      </div>
    </section>
  )
}
