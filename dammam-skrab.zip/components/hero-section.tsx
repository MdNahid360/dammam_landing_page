import { Button } from "@/components/ui/button"
import { Icons } from "./icons"
import Link from "next/link"
import { socialLinks } from "@/lib/links"

export function HeroSection() {
  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-visible py-12">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/images/hero-banner.webp?height=800&width=1200')`,
        }}
      />
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-primary/20" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            شراء الأثاث المستعمل والمكيفات السكراب بالدمام
            <span className="block gradient-text">بأعلى الأسعار</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-100 leading-relaxed">
            هل تبحث عن أفضل شركة شراء أثاث مستعمل أو مكيفات سكراب أو معادن خردة في الدمام والخبر والقطيف والجبيل والأحساء؟ نحن نقدم لك أفضل الأسعار، نقل مجاني، وخدمة سريعة وموثوقة. نشتري جميع أنواع الأثاث المستعمل، المكيفات المعطلة، سكراب الحديد، النحاس، الألمنيوم، والمزيد.
            <br />
            نقل مجاني • أسعار تنافسية • خدمة سريعة • تقييم فوري
          </p>

          <div className="flex flex-row gap-4 justify-center items-center pb-8">
            <Button
              asChild
              size="icon"
              className="gradient-bg hover:opacity-90 transition-opacity"
            >
              <Link
                rel="noopener noreferrer"
                href={socialLinks.whatsapp}
              >
                <Icons.whatsapp className="w-6 h-6" />
              </Link>
            </Button>

            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-primary px-8 py-4 bg-transparent"
            >
              <Link href="/services">
                تفضل بزيارة خدماتنا
                <Icons.arrowRight className="w-5 h-5 mr-2" />
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Glossy Stats Box (Half Overlapping Hero Banner) */}
      <div className="max-w-4xl mx-auto absolute left-1/2 -bottom-24 md:-bottom-32 transform -translate-x-1/2 w-11/12 md:w-10/12 border border-white/20 rounded-tr-4xl rounded-bl-4xl shadow-xl p-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-white bg-primary md:min-h-48 justify-center items-center">
        <div className="absolute inset-0 bg-black/20 rounded-tr-4xl rounded-bl-4xl" />
        <div className="animate-slide-up bg-white/0 backdrop-blur-xs py-1 rounded-xl">
          <div className="text-xl md:text-3xl font-bold text-primary-foreground">+350</div>
          <div className="text-sm">عميل راضي</div>
        </div>
        <div className="animate-slide-up bg-white/0 backdrop-blur-xs py-1 rounded-xl ">
          <div className="text-xl md:text-3xl font-bold text-primary-foreground">24/7</div>
          <div className="text-sm">خدمة متاحة</div>
        </div>
        <div className="animate-slide-up bg-white/0 backdrop-blur-xs py-1 rounded-xl ">
          <div className="text-xl md:text-3xl font-bold text-primary-foreground">مجاني</div>
          <div className="text-sm">النقل والتقييم</div>
        </div>
        <div className="animate-slide-up bg-white/0 backdrop-blur-xs py-1 rounded-xl ">
          <div className="text-xl md:text-3xl font-bold text-primary-foreground">أعلى</div>
          <div className="text-sm">الأسعار</div>
        </div>
      </div>
    </section>

  )
}
