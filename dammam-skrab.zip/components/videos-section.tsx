import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Icons } from "./icons"
import { videos } from "@/data/videos"
import Link from "next/link"
import { internalLinks } from "@/lib/links"

export function VideosSection() {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4">
            شاهد مقاطع الفيديو لخدماتنا في شراء{' '}
            <Link href={internalLinks.usedFurniture} className="gradient-text hover:border-b-2 border-b-primary">
              الأثاث المستعمل
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-b-primary">
              في الدمام المكيفات المستعملة
            </Link>{' '}

          </h2>

          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            تعرف على خدماتنا المتخصصة من خلال الفيديوهات التوضيحية التي توضح عملية{' '}
            <Link href={internalLinks.usedFurnitureDammam} className="gradient-text hover:border-b-2 border-b-primary">
              شراء الأثاث المستعمل بالدمام
            </Link>،{' '}
            <Link href={internalLinks.scrapACs} className="gradient-text hover:border-b-2 border-b-primary">
              مكيفات السكراب
            </Link>،{' '}
            <Link href={internalLinks.restaurantEquipment} className="gradient-text hover:border-b-2 border-b-primary">
              معدات المطاعم المستعملة
            </Link>، و{' '}
            <Link href={internalLinks.scrapMetals} className="gradient-text hover:border-b-2 border-b-primary">
              المعادن والخردة
            </Link>{' '}
            في جميع أنحاء المنطقة الشرقية بأعلى الأسعار وأفضل الخدمات.
          </p>
        </div>

        {/* Videos Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {videos.slice(0, 4).map((video, index) => (
            <Card
              key={video.id}
              className="animate-slide-up shadow-none transition-all duration-300 !bg-transparent border-0"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-0">
                <figure>
                  <video
                    controls
                    preload="metadata"
                    className="w-full rounded-lg"
                    title={video.eng_title}
                    aria-label={video.title}
                  >
                    <source src={video.videoUrl} type="video/mp4" />
                    متصفحك لا يدعم تشغيل الفيديو
                  </video>
                  <figcaption className="mt-4">
                    <h3 className="font-bold text-lg">{video.title}</h3>
                    <p className="text-muted-foreground text-sm">{video.description}</p>
                  </figcaption>
                </figure>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
            <a href="/videos">
              مشاهدة جميع الفيديوهات
              <Icons.arrowRight className="w-4 h-4 mr-2" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
