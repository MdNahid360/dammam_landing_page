import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Icons } from "./icons"
import Link from "next/link"
import { reviews } from "@/data/reviews"
import { internalLinks } from "@/lib/links"

export function TestimonialsSection() {
  // Show only first 6 reviews on homepage
  const featuredReviews = reviews.slice(0, 3)
  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4">
            آراء عملائنا في شراء{' '}
            <Link href={internalLinks.usedFurniture} className="gradient-text hover:border-b-2 border-b-primary">
              الأثاث المستعمل
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-b-primary">
              المكيفات المستعملة
            </Link>{' '}
            بالدمام والمنطقة الشرقية
          </h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            اقرأ تجارب عملائنا الحقيقية معنا في{' '}
            <Link href={internalLinks.usedFurnitureDammam} className="gradient-text hover:border-b-2 border-b-primary">
              شراء الأثاث المستعمل بالدمام
            </Link>،{' '}
            <Link href={internalLinks.scrapACs} className="gradient-text hover:border-b-2 border-b-primary">
              مكيفات السكراب
            </Link>،{' '}
            <Link href={internalLinks.restaurantEquipment} className="gradient-text hover:border-b-2 border-b-primary">
              معدات المطاعم المستعملة
            </Link>، و{' '}
            <Link href={internalLinks.scrapMetals} className="gradient-text hover:border-b-2 border-b-primary">
              خردة المعادن
            </Link>{' '}
            في الخبر، القطيف، الجبيل، والأحساء
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredReviews.map((review, index) => (
            <Card
              key={review._id}
              className="animate-slide-up hover:shadow-xl transition-all duration-300 group overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6 relative">
                {/* Service Badge */}
                <div className="absolute top-4 right-4 bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium">
                  {review.service}
                </div>

                {/* Rating Stars */}
                <div className="flex items-center gap-1 mb-4 mt-6">
                  {[...Array(review.rating)].map((_, i) => (
                    <Icons.star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-muted-foreground mr-2">({review.rating}.0)</span>
                </div>

                {/* Review Comment */}
                <p className="text-muted-foreground mb-6 leading-relaxed italic text-sm group-hover:text-foreground transition-colors">
                  "{review.comment}"
                </p>

                {/* Customer Info */}
                <div className="border-t pt-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-semibold text-foreground">{review.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                        <Icons.mapPin className="w-3 h-3 text-primary" />
                        {review.location}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(review.date).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </div>
                    </div>

                    {/* Verified Badge */}
                    <div className="flex items-center gap-1 text-green-600 text-xs">
                      <Icons.checkCircle className="w-4 h-4" />
                      <span>عميل معتمد</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Statistics and CTA */}
        <div className="text-center mt-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="animate-fade-in">
              <div className="text-3xl font-bold text-primary mb-2">+1000</div>
              <div className="text-muted-foreground">عميل راضي</div>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Icons.star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="font-bold text-2xl text-primary">{averageRating.toFixed(1)}</span>
              </div>
              <div className="text-muted-foreground">متوسط التقييم ({reviews.length} تقييم)</div>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <div className="text-3xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">خدمة متاحة</div>
            </div>
          </div>

          <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
            انضم إلى آلاف العملاء الراضين عن خدماتنا في شراء الأثاث المستعمل والمكيفات السكراب
            <br />
            <span className="text-primary font-semibold">أعلى الأسعار مضمونة في جميع أنحاء المنطقة الشرقية</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button asChild size="lg">
              <Link href="/reviews">
                اقرأ جميع التقييمات
                <Icons.arrowRight className="w-4 h-4 mr-2" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="tel:+966554268296">
                <Icons.phone className="w-4 h-4 ml-2" />
                احصل على تقييم مجاني
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}