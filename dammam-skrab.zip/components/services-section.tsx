
import { Icons } from "./icons"
import Link from "next/link"
import { API_ENDPOINTS } from "@/lib/utils"
import { Service } from "@/types"
import ServiceCard from "./service-card"
import { servicesLinks } from "@/lib/links"

async function getServices(): Promise<Service[]> {
  try {
    const res = await fetch(`${API_ENDPOINTS.services}?domain=${API_ENDPOINTS.domain}&limit=9&offset=0`, {
      next: { revalidate: 60 * 60 * 2 }, // Cache for 2 hours
    })
    if (!res.ok) throw new Error("Failed to fetch")
    const json = await res.json()
    // API returns { data: Service[] }
    return json?.services ?? []
  } catch {
    return []
  }
}

export async function ServicesSection() {
  const services = await getServices()

  if (services.length === 0) return null
  return (
    <section className="py-20 bg-muted/50 pt-48">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-2xl md:text-3xl font-semibold mb-4">
            <Link href={servicesLinks.usedFurniture}>
              <strong className="font-bold gradient-text hover:border-b-2 border-primary">
                شراء الأثاث المستعمل بالدمام
              </strong>
            </Link>{' '}
            وخدمات أخرى تشمل{' '}
            <Link href={servicesLinks.usedAirConditioners}>
              المكيفات المستعملة
            </Link>،{' '}
            <Link href={servicesLinks.scrapAirConditioners}>
              مكيفات السكراب
            </Link>،{' '}
            وتدوير المعادن الخردة
          </h2>

          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>

          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            نحن شركة متخصصة في شراء{' '}
            <Link href={servicesLinks.usedFurniture}>
              <strong className="gradient-text hover:border-b-2 border-primary">الأثاث المستعمل بالدمام والخبر</strong>
            </Link>،{' '}
            <Link href={servicesLinks.usedAirConditioners}>
              <strong className="gradient-text hover:border-b-2 border-primary">المكيفات المستعملة</strong>
            </Link>،{' '}
            <Link href={servicesLinks.scrapAirConditioners}>
              <strong className="gradient-text hover:border-b-2 border-primary">مكيفات السكراب</strong>
            </Link>، و{' '}
            <Link href={servicesLinks.scrapMetals}>
              <strong className="gradient-text hover:border-b-2 border-primary">سكراب المعادن والخردة</strong>
            </Link>{' '}
            بجميع أنواعها مثل الحديد، النحاس، والألمنيوم. كما نشتري{' '}
            <Link href={servicesLinks.usedRestaurantEquipment}>
              <strong className="gradient-text hover:border-b-2 border-primary">معدات المطاعم المستعملة</strong>
            </Link>{' '}
            و{' '}
            <Link href={servicesLinks.usedHomeAppliances}>
              <strong className="gradient-text hover:border-b-2 border-primary">الأجهزة الكهربائية المستعملة</strong>
            </Link>.
            نخدم كافة مناطق الشرقية بما في ذلك الدمام، الخبر، القطيف، الجبيل، الأحساء، الهفوف، والمناطق المجاورة بأعلى الأسعار وأفضل الخدمات.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={service._id} service={service} />
          ))}
        </div>
      </div>

      <div className="text-center mt-12">
        <Link href="/services" className="inline-flex items-center text-primary hover:text-primary/80"
          rel="noopener noreferrer"
        >
          تصفح جميع الخدمات
          <Icons.arrowRight className="w-4 h-4 mr-2" />
        </Link>
      </div>
    </section>
  )
}
