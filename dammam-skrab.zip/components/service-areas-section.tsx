import { Card, CardContent } from "@/components/ui/card"
import { Icons } from "./icons"
import { internalLinks, socialLinks } from "@/lib/links"
import Link from "next/link"
import Image from "next/image"

const serviceAreas = [
  {
    name: "الدمام",
    description: "شراء الأثاث المستعمل والمكيفات السكراب في الدمام وجميع الأحياء بأعلى الأسعار",
    image: "/images/dammam-air-conditioner-scrap.jpg",
    services: ["أثاث مستعمل", "مكيفات سكراب", "معادن خردة"]
  },
  {
    name: "الخبر",
    description: "خدمات شراء الأثاث المستعمل والمكيفات المستعملة في الخبر بخدمة سريعة ونقل مجاني",
    image: "/images/khobar-used-dining-room-furniture.jpg",
    services: ["أثاث مستعمل", "مكيفات مستعملة", "معدات مطاعم"]
  },
  {
    name: "القطيف",
    description: "نشتري جميع أنواع الأثاث المستعمل ومكيفات السكراب في القطيف والمناطق المحيطة",
    image: "/images/qatif-used-furniture.jpg",
    services: ["مكيفات سكراب", "أثاث مستعمل", "أجهزة كهربائية"]
  },
  {
    name: "الجبيل",
    description: "شراء الأثاث المكتبي المستعمل ومكيفات السكراب الجبيل - خدمة متخصصة للشركات والمصانع",
    image: "/images/jubail-office-furniture.jpg",
    services: ["أثاث مكتبي", "مكيفات سكراب", "معدات صناعية"]
  },
  {
    name: "الأحساء",
    description: "خدمات شراء الأثاث المستعمل ومعدات المطاعم المستعملة في الأحساء بتقييم فوري",
    image: "/images/ahsa-restaurant-equipment.jpg",
    services: ["معدات مطاعم", "أثاث مستعمل", "مطابخ مستعملة"]
  },
  {
    name: "الهفوف",
    description: "شراء الأثاث المستعمل ومكيفات السكراب الهفوف بأفضل الأسعار وخدمة على مدار الساعة",
    image: "/images/hofuf-used-and-scrap-airconditioner.jpg",
    services: ["مكيفات سكراب", "أثاث منزلي", "خردة معادن"]
  },
]

export function ServiceAreasSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4">
            خدمات شراء{' '}
            <Link href={internalLinks.scrapAirConditioners} className="gradient-text hover:border-b-2 border-primary">
              <strong>مكيفات سكراب</strong>
            </Link>{' '}
            و{' '}
            <Link href={internalLinks.usedFurniture} className="gradient-text hover:border-b-2 border-primary">
              الأثاث المستعمل
            </Link>{' '}
            في الدمام والمنطقة الشرقية
          </h2>

          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            نقدم خدماتنا المتخصصة في جميع مدن المنطقة الشرقية: الدمام، الخبر، القطيف، الجبيل، الأحساء، والهفوف.
            متخصصون في{" "}
            <Link href={internalLinks.usedFurnitureDammam} className="gradient-text hover:border-b-2 border-primary">
              شراء الأثاث المستعمل بالدمام
            </Link>،{" "}
            <Link href={internalLinks.usedAirConditioners} className="gradient-text hover:border-b-2 border-primary">
              شراء المكيفات المستعملة والسكراب
            </Link>،{" "}
            <Link href={internalLinks.restaurantEquipment} className="gradient-text hover:border-b-2 border-primary">
              معدات المطاعم المستعملة
            </Link>، و{" "}
            <Link href={internalLinks.scrapMetals} className="gradient-text hover:border-b-2 border-primary">
              جميع أنواع المعادن والخردة
            </Link>
            .
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceAreas.map((area, index) => (
            <Card
              key={area.name}
              className="group hover:shadow-xl transition-all duration-300 animate-slide-up overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-0">
                {/* Image Section */}
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={area.image}
                    alt={`خدمات شراء الأثاث المستعمل في ${area.name}`}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-bold text-white mb-2">{area.name}</h3>
                    <div className="flex flex-wrap gap-1">
                      {area.services.map((service, idx) => (
                        <span
                          key={idx}
                          className="text-xs bg-white/20 backdrop-blur-sm text-white px-2 py-1 rounded-full"
                        >
                          {service}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-6">
                  <p className="text-muted-foreground mb-4 leading-relaxed text-sm">
                    {area.description}
                  </p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-primary">
                      <Icons.mapPin className="w-4 h-4" />
                      <span className="text-sm font-medium">خدمة محلية</span>
                    </div>

                    <Link
                      href={socialLinks.phone}
                      className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors font-medium text-sm"
                    >
                      <Icons.phone className="w-4 h-4" />
                      اتصل الآن
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Coverage Note */}
        <div className="text-center mt-12 animate-fade-in">
          <p className="text-lg text-muted-foreground">
            كما نخدم جميع المناطق المحيطة والأحياء الفرعية في المنطقة الشرقية
            <br />
            <span className="text-primary font-semibold">خدمة طوارئ 24/7 متاحة في جميع المناطق</span>
          </p>
        </div>
      </div>
    </section>
  )
}