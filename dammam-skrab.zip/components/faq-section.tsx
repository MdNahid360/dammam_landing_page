
import Image from "next/image"

type Faq = {
  question: string
  answer: string
}

export function FaqSection({ faqs }: { faqs: Faq[] }) {
  return (
    <section id="faq" className="py-24 px-8 max-w-7xl mx-auto flex flex-col md:flex-row gap-12">
      <div className="flex flex-col text-left basis-1/2">
        <h2 className="sm:text-4xl text-3xl font-extrabold text-base-content">
          الأسئلة المتكررة حول خدماتنا
        </h2>
        <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>

        <div>
          <Image
            src="/images/faq.webp" alt="faq" width={500} height={500} className="w-full rounded-lg" />
        </div>
      </div>

      <ul className="basis-1/2">
        {faqs.map(({ question, answer }, i) => (
          <li key={i} className="border-t border-base-content/10">
            <details className="group" tabIndex={0}>
              <summary
                className="relative flex gap-2 items-center w-full py-5 text-base font-semibold text-left cursor-pointer md:text-lg list-none"
                aria-expanded="false"
              >
                <span className="flex-1 text-base-content">{question}</span>
                <svg className="flex-shrink-0 w-4 h-4 ml-auto fill-current" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                  <rect y="7" width="16" height="2" rx="1" className="transform origin-center transition duration-200 ease-out false"></rect>
                  <rect y="7" width="16" height="2" rx="1" className="transform origin-center rotate-90 transition duration-200 ease-out false"></rect>
                </svg>
              </summary>
              <div className="pb-5 leading-relaxed text-base-content">
                <div className="space-y-2 leading-relaxed">{answer}</div>
              </div>
            </details>
          </li>
        ))}
      </ul>
    </section>
  )
}
