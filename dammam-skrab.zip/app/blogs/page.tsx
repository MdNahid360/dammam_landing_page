import type { Metadata } from "next"
import { API_ENDPOINTS } from "@/lib/utils"
import { Blog } from "@/types"
import BlogCard from "@/components/blog-card"
import { internalLinks } from "@/lib/links"
import Link from "next/link"

export const metadata: Metadata = {
  title: "مدونتنا - نصائح ومقالات شراء مكيفات السكراب والمعادن",
  description:
    "اقرأ أحدث المقالات والنصائح حول شراء السكراب والمعادن، أسعار المكيفات، وطرق التقييم في المنطقة الشرقية.",
  keywords: ["مدونة مكيفات سكراب", "نصائح شراء سكراب", "أسعار مكيفات سكراب", "مقالات معادن خردة"],
  authors: [{ name: "مكيفات سكراب الدمام" }],
  creator: "مكيفات سكراب الدمام",
  publisher: "مكيفات سكراب الدمام",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "ar_SA",
    url: "https://www.dammamathathmukayfat.com/blogs",
    siteName: "مكيفات سكراب الدمام",
    title: "مدونتنا - نصائح ومقالات شراء مكيفات السكراب والمعادن",
    description:
      "اقرأ أحدث المقالات والنصائح حول شراء السكراب والمعادن، أسعار المكيفات، وطرق التقييم في المنطقة الشرقية.",
  },
  twitter: {
    card: "summary_large_image",
    title: "مدونتنا - نصائح ومقالات شراء مكيفات السكراب والمعادن",
    description:
      "اقرأ أحدث المقالات والنصائح حول شراء السكراب والمعادن، أسعار المكيفات، وطرق التقييم في المنطقة الشرقية.",
  },
  alternates: {
    canonical: "https://www.dammamathathmukayfat.com/blogs",
  },
}

async function getBlogs(): Promise<Blog[]> {
  try {
    const res = await fetch(
      `${API_ENDPOINTS.blogs}?domain=${API_ENDPOINTS.domain}&limit=20&offset=0`,
      {
        next: { revalidate: 60 * 60 * 2 }, // Cache for 2 hours
      }
    );
    if (!res.ok) return [];
    const json = await res.json();
    return json?.blogs ?? [];
  } catch {
    return [];
  }
}

export default async function BlogsPage() {
  const blogs = await getBlogs();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              نصائح حول <Link
                rel="noopener"
                href={internalLinks.scrapQatif} className="border-gradient-b gradient-text">شراء سكراب القطيف</Link> والمزيد
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              تابع أحدث المقالات عن{" "}
              <Link
                rel="noopener"
                href={internalLinks.scrapMetals} className="gradient-text border-gradient-b">شراء خردة المعادن</Link> و{" "}
              <Link
                rel="noopener"
                href={internalLinks.scrapACs} className="gradient-text border-gradient-b">مكيفات السكراب</Link> في القطيف، الخبر، الجبيل والمنطقة الشرقية.
              نقدم أيضاً خدمات{" "}
              <Link
                rel="noopener"
                href={internalLinks.restaurantEquipment} className="gradient-text border-gradient-b">شراء معدات مطاعم مستعملة</Link>،{" "}
              <Link
                rel="noopener"
                href={internalLinks.officeFurniture} className="gradient-text border-gradient-b">الأثاث المكتبي</Link>، و{" "}
              <Link
                rel="noopener"
                href={internalLinks.usedKitchens} className="gradient-text border-gradient-b">المطابخ المستعملة</Link> بأعلى الأسعار، بالإضافة إلى{" "}
              <Link
                rel="noopener"
                href={internalLinks.allScrap} className="gradient-text border-gradient-b">شراء جميع أنواع السكراب
              </Link>.
            </p>
          </div>
        </div>
      </section>

      {/* Blogs Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogs.map((blog: Blog) => (
              <BlogCard key={blog._id} blog={blog} />
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
