import type { Metadata } from "next"
import { videos } from "@/data/videos"
import { Card, CardContent } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "فيديوهاتنا - مكيفات سكراب الدمام | شاهد خدماتنا",
  description:
    "شاهد فيديوهات توضيحية عن خدمات شراء مكيفات السكراب والمعادن، طرق التقييم، وعملية النقل في المنطقة الشرقية.",
  keywords: "فيديوهات مكيفات سكراب, شرح خدمات شراء سكراب, فيديو تقييم مكيفات, طريقة شراء خردة",
  alternates: {
    canonical: "https://www.dammamathathmukayfat.com/videos",
  },
}

export default function VideosPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">فيديوهاتنا</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              شاهد فيديوهات توضيحية عن خدماتنا وطرق عملنا في شراء السكراب والمعادن
            </p>
          </div>
        </div>
      </section>

      {/* Videos Section */}
      <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 pb-12 md:pb-16">
        {videos.slice(0, 4).map((video, index) => (
          <Card
            key={video.id}
            className="animate-slide-up hover:shadow-lg transition-all duration-300"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardContent className="p-4">
              <figure>
                <video
                  controls
                  preload="metadata"
                  className="w-full rounded-lg"
                  title={video.eng_title}
                  aria-label={video.title}
                >
                  <source src={video.videoUrl} type="video/mp4" />
                  متصفحك لا يدعم تشغيل الفيديو
                </video>
                <figcaption className="mt-4">
                  <h3 className="font-bold text-lg">{video.title}</h3>
                  <p className="text-muted-foreground text-sm">{video.description}</p>
                </figcaption>
              </figure>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
